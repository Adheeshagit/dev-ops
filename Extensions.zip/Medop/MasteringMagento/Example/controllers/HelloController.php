<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:05 PM
 */
class MasteringMagento_Example_HelloController extends Mage_Core_Controller_Front_Action
{
    public function worldAction(){
        echo 'Hello, World';
    }
    public function indexAction(){
        echo 'Hello, index';
    }
}