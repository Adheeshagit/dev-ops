<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:51 PM
 */
class MasteringMagento_Example_Adminhtml_ExampleController extends Mage_Adminhtml_Controller_Action{
    public function indexAction(){
//        $this->loadLayout();
//        return $this->renderLayout();

        $event = Mage::getModel('example/event');
//        echo '<pre>';
//        var_dump($event);exit;
        $event->setName('Test Event')->save();


        Mage::getSingleton('adminhtml/session')->addSuccess('Event saved. ID = ' .$event->getId());

        $this->loadLayout();
        return $this->renderLayout();
    }
}