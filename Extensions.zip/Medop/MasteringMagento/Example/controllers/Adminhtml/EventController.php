<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:51 PM
 */
class MasteringMagento_Example_Adminhtml_EventController extends Mage_Adminhtml_Controller_Action{
    public function indexAction(){
        $this->loadLayout();
        $this->_setActiveMenu('example/events');
        $this->_addContent(
            $this->getLayout()->createBlock('example/adminhtml_event')
        );
        return $this->renderLayout();
    }
}