<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/3/16
 * Time: 10:12 PM
 */
class MasteringMagento_Example_Block_Adminhtml_Event extends
Mage_Adminhtml_Block_Widget_Grid_Container{
    public function __construct(){
        $this->_blockGroup = 'example';
        $this->_controller = 'adminhtml_event';
        $this->_headerText = Mage::helper('example')->__('Events');
        $this->_addButtonLabel = Mage::helper('example')->__('Add New Events');
        parent::__construct();
    }
}