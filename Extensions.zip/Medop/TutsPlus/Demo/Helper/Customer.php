<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/20/16
 * Time: 9:43 PM
 */
class TutsPlus_Demo_Helper_Customer extends Mage_Core_Helper_Abstract{
    public function sayHello(){
        echo 'hi';
    }
}