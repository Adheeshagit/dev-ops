<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/20/16
 * Time: 9:31 PM
 */
class TutsPlus_Demo_Model_Product{
    public function sayHello(){
        echo "Hellooo";
    }
}