<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/20/16
 * Time: 10:25 PM
 */
class TutsPlus_Demo_Model_Observer{
    public function logCustomer($observer){
        $customer = $observer->getCustomer();
        Mage::log($customer->getName()." has logged in...", null, "customer.log");
    }
}