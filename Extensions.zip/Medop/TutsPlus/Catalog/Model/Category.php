<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/20/16
 * Time: 10:04 PM
 */
class TutsPlus_Catalog_Model_Category extends Mage_Catalog_Model_Category{

//    public function getChildren()
//    {
////        return implode(',', $this->getResource()->getChildren($this, false));
//    }
}