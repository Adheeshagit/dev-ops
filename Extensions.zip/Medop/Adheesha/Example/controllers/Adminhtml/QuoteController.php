<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:51 PM
 */
class Adheesha_Example_Adminhtml_QuoteController extends Mage_Adminhtml_Controller_Action{
    public function indexAction(){
        $this->loadLayout();
        $this->_setActiveMenu('example/quotes');
        $this->_addContent(
            $this->getLayout()->createBlock('example/adminhtml_quote')
        );
        return $this->renderLayout();
    }

    public function newAction(){
        $this->_forward('edit');
    }

    public function editAction(){
        if ($quoteId = $this->getRequest()->getParam('quote_id')){
            Mage::register('current_quote',Mage::getModel('example/quote')->load($quoteId));
        }

        $this->loadLayout();
        $this->_setActiveMenu('example/quotes');

        $this->_addContent(
            $this->getLayout()->createBlock('example/adminhtml_quote_edit')
        );

        return $this->renderLayout();
    }

    public function saveAction(){
        $quoteId = $this->getRequest()->getParam('quote_id');
        $quoteModel = Mage::getModel('example/quote')->load($quoteId);

        if ($data = $this->getRequest()->getPost()){
            try{
                $quoteModel->addData($data)->save();
                Mage::getSingleton('adminhtml/session')->addSuccess($this->__("Your quote has been saved."));
            } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')->setQuoteFormData($data);
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit',array('_current' => true));
            }
            $this->_redirect('*/*/index');
}
    }

    public function deleteAction(){
        $quoteId = $this->getRequest()->getParam('quote_id');
        $quoteModel = Mage::getModel('example/quote')->load($quoteId);


            try{
                $quoteModel->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess($this->__("Your quote has been deleted."));
            } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit',array('_current' => true));
            }
            $this->_redirect('*/*/index');

    }
}