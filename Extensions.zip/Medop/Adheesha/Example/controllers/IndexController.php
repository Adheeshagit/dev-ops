<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:05 PM
 */
class Adheesha_Example_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction(){
//        echo 'Hello, World. this is index';
        $this->loadLayout();
        return $this->renderLayout();
    }

    public function saveAction()
    {
        $post = $this->getRequest()->getPost();
        $name = $post['name'];
        $email = $post['email'];
        $date = $post['date'];
//        echo "<pre>";
//        print_r($post);
//        echo "</pre>";

        $quote = Mage::getModel('example/quote');
//        echo '<pre>';
//        var_dump($quote);exit;
        $quote->setName($name);
        $quote->setEmail($email);
        $quote->setDate($date);
        $quote->setCreatedAt(date("Y-m-d H:i:s"));
        $quote->setModifiedAt(date("Y-m-d H:i:s"));
        $quote->save();


        Mage::getSingleton('core/session')->addSuccess('Quote saved. ID = ' .$quote->getId());

        $this->loadLayout();
        return $this->renderLayout();
    }
}