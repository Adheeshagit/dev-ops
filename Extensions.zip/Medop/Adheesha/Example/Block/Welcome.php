<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 11:28 PM
 */
class Adheesha_Example_Block_Welcome extends Mage_Core_Block_Template{
    public function _construct(){
        parent::_construct();
//        $this->setTemplate('example/welcome.phtml');
        $this->setTemplate('example/welcome.phtml');
    }
}