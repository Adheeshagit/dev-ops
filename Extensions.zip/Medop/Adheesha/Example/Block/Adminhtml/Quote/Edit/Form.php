<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/4/16
 * Time: 10:33 PM
 */

class Adheesha_Example_Block_Adminhtml_Quote_Edit_Form extends Mage_Adminhtml_Block_Widget_Form{

    protected function _initFormValues(){
        //For editing existing quotes
        if ( $quote = Mage::registry('current_quote')){
            $data = $quote->getData();

            $this->getForm()->setValues($data);
        }

        //In order to keep data in failed save
        if ($data = Mage::getSingleton('adminhtml/session')->getData('quote_form_data', true)){
            $this->getForm()->setValues($data);
        }
    }

    protected function _prepareForm(){
        $form = new Varien_Data_Form(
            array('id'=>'edit_form','action'=> $this->getData('action'),'method' => 'post')
        );

        $fieldset = $form->addFieldset('base_fieldset',array('legend'=>Mage::helper('example')->__('General Information'),'class'=>'fieldset-wide'));

        $fieldset->addField('name','text',array(
            'name'  => 'name',
            'label' =>Mage::helper('example')->__('Event Name'),
            'title' =>Mage::helper('example')->__('Event Name'),
            'required'=>true
        ));

        $fieldset->addField('email','text',array(
            'name'  => 'email',
            'label' =>Mage::helper('example')->__('Email'),
            'title' =>Mage::helper('example')->__('Email'),
            'required'=>true
        ));

        $dateFormatIso = Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT);
        $fieldset->addField('date','date',array(
            'name'  => 'date',
            'format'  => $dateFormatIso,
            'image' => $this->getSkinUrl('images/grid-cal.gif'),
            'label' =>Mage::helper('example')->__('Date'),
            'title' =>Mage::helper('example')->__('Date'),
            'required'=>true
        ));

        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}