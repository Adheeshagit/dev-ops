<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/3/16
 * Time: 10:21 PM
 */

class Adheesha_Example_Block_Adminhtml_Quote_Grid extends Mage_Adminhtml_Block_Widget_Grid{

    public function getRowUrl($item){
        return $this->getUrl('*/quote/edit',array('quote_id'=>$item->getId()));
    }

    protected function _prepareCollection(){
        $collection = Mage::getModel('example/quote')->getCollection();
        //var_dump($collection);exit;
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns(){
        $this->addColumn('name', array(
            'type'=> 'text',
            'index'=> 'name',
            'header'=> $this->__('Name'),
        ));

        $this->addColumn('email', array(
            'type'=> 'text',
            'index'=> 'email',
            'header'=> $this->__('Email'),
        ));

        $this->addColumn('date', array(
            'type'=> 'date',
            'index'=> 'date',
            'header'=> $this->__('Date'),
        ));

        return $this;
    }
}