<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/4/16
 * Time: 11:00 PM
 */
class Adheesha_Example_Block_Adminhtml_Quote_Edit extends Mage_Adminhtml_Block_Widget_Form_Container{
    public function __construct(){
        $this->_objectId = 'quote_id';
        $this->_blockGroup = 'example';
        $this->_controller = 'adminhtml_quote';

        parent::__construct();
    }

    public function getHeaderText(){
        return Mage::helper('example')->__('New Quote');
    }

    public function getSaveUrl(){
        return $this->getUrl('*/quote/save',array('_current' => true));
    }
}