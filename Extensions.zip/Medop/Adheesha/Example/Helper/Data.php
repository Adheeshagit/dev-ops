<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 11/26/16
 * Time: 10:53 PM
 */
class Adheesha_Example_Helper_Data extends Mage_Core_Helper_Abstract
{

}