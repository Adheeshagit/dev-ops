<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/3/16
 * Time: 6:11 PM
 */
class Adheesha_Example_Model_Resource_Quote extends
    Mage_Core_Model_Resource_Db_Abstract
{
    public function _construct(){
        $this->_init('example/quote','quote_id');
    }
}