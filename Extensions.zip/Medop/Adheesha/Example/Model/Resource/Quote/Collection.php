<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/12/16
 * Time: 3:40 PM
 * To change this template use File | Settings | File Templates.
 */

class Adheesha_Example_Model_Resource_Quote_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    /**
     * Define resource model
     *
     */
    protected function _construct()
    {
        $this->_init('example/quote');
    }
}