<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/3/16
 * Time: 6:08 PM
 */
class Adheesha_Example_Model_Quote extends Mage_Core_Model_Abstract{
    public function _construct(){
        $this->_init('example/quote');
    }
}