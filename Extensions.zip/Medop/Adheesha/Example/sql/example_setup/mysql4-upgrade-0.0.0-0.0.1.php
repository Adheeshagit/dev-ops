<?php
/**
 * Created by PhpStorm.
 * User: Adheesha Perera
 * Date: 12/3/16
 * Time: 8:54 PM
 */
/*@var $this Mage_Core_Model_Resource_Setup*/
$this->startSetup();

$this->run("
CREATE TABLE {$this->getTable('example/quote')}(
  `quote_id` INTEGER AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255),
  `email` VARCHAR(255),
  `date` DATETIME,
  `created_at` DATETIME,
  `modified_at` DATETIME
);
");

$this->endSetup();