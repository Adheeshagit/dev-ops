<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 5/16/16
 * Time: 5:57 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_Model_Index extends Mage_Core_Model_Abstract {
    protected $_eventPrefix = 'checkout';
    protected $_resourceName = 'checkout/index';

    public function save($data){

        Mage::getModel('checkout/index')->setData($data)->save();

    }
}
