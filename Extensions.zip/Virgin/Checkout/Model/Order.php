<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/11/16
 * Time: 9:45 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_Model_Order extends Mage_Core_Model_Abstract{
    public function _construct(){
        $this->_init('checkout/order');
    }
}