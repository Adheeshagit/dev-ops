<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/11/16
 * Time: 5:25 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_Block_Adminhtml_Order extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_blockGroup = 'checkout';
        $this->_controller = 'adminhtml_order';
        $this->_headerText = Mage::helper('checkout')->__('Orders');
        $this->_addButtonLabel = Mage::helper('checkout')->__('Add new Order');
        parent::__construct();
        //$this->_removeButton('add');
    }
}