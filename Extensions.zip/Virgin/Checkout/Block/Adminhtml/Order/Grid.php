<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/11/16
 * Time: 5:31 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_Block_Adminhtml_Order_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    protected function _prepareCollection()
    {
        $collection = Mage::getModel('checkout/order')->getCollection();

        //var_dump($collection);exit;
        $this->setCollection($collection);
        return parent::_prepareCollection();
        //return $this;
    }

    protected function _prepareColumns()
    {
        $this->addColumn('name', array(
            'type' => 'text',
            'index'  => 'customer_name',
            'header' => $this->__('Customer Name'),
        ));

        $this->addColumn('start', array(
            'type' => 'date',
            'index'  => 'start',
            'header' => $this->__('Start Date'),
        ));

        $this->addColumn('end', array(
            'type' => 'date',
            'index'  => 'end',
            'header' => $this->__('End Date'),
        ));

        return $this;
    }
}