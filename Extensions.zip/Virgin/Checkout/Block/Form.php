<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 5/13/16
 * Time: 12:18 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_Block_Form extends Mage_Core_Block_Template{

    public function checkoutForm(){
        return 'Working..';
    }
}