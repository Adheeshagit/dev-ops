<?php
class Virgin_Checkout_Helper_Data extends Mage_Core_Helper_Abstract
{
}