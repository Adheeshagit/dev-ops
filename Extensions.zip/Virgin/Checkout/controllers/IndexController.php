<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 5/13/16
 * Time: 12:40 PM
 * To change this template use File | Settings | File Templates.
 */

class Virgin_Checkout_IndexController extends Mage_Core_Controller_Front_Action{

    public function indexAction() {

        $this->loadLayout();
        $this->renderLayout();
    }

    public function loginAction() {
       // echo 'faffafa';
        $this->loadLayout();
        $this->renderLayout();
    }

    public function loginSaveAction(){
        $session = Mage::getSingleton('customer/session');
        if ($session->isLoggedIn()) {
            // is already login redirect to account page
            $home_url = Mage::helper('core/url')->getHomeUrl();

            header("Location: $home_url"); /* Redirect browser */
            exit();
        }

        $result = array('success' => false);

        if ($this->getRequest()->isPost())
        {
            $login_data = $this->getRequest()->getPost('login');
            if (empty($login_data['username']) || empty($login_data['password'])) {
                $result['error'] = Mage::helper('onepagecheckout')->__('Login and password are required.');
            }
            else
            {
                try
                {
                    $session->login($login_data['username'], $login_data['password']);
                    $result['success'] = true;
                    $result['redirect'] = Mage::getUrl('*/*/index');
                }
                catch (Mage_Core_Exception $e)
                {
                    switch ($e->getCode()) {
                        case Mage_Customer_Model_Customer::EXCEPTION_EMAIL_NOT_CONFIRMED:
                            $message = Mage::helper('onepagecheckout')->__('Email is not confirmed. <a href="%s">Resend confirmation email.</a>', Mage::helper('customer')->getEmailConfirmationUrl($login_data['username']));
                            break;
                        default:
                            $message = $e->getMessage();
                    }
                    $result['error'] = $message;
                    $session->setUsername($login_data['username']);
                }
            }
        }

        //$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
        $home_url = Mage::helper('core/url')->getHomeUrl();

        header("Location: $home_url"); /* Redirect browser */
        exit();
    }

    public function saveAction(){

        $write = Mage::getSingleton("core/resource")->getConnection("core_write");

        $vmcheckout = $this->getRequest()->getPost();

        echo "<pre>";
        print_r($vmcheckout);
        exit;
        echo "</pre>";

        if ($vmcheckout['other-cost-center']){
            $query = "insert into vm_checkout "
                . "(lrs_location, cost_center, customer_name, customer_id, customer_email, customer_mobile,hod_name, hod_email, afm_name, afm_email) values "
                . "(:lrs_location, :other-cost-center, :customer_name, :customer_id, :customer_email, :customer_mobile,:hod_name,:hod_email,:afm_name,:afm_email)";
        } else {
            $query = "insert into vm_checkout "
                . "(lrs_location, cost_center, customer_name, customer_id, customer_email, customer_mobile,hod_name, hod_email, afm_name, afm_email) values "
                . "(:lrs_location, :cost_center, :customer_name, :customer_id, :customer_email, :customer_mobile,:hod_name,:hod_email,:afm_name,:afm_email)";
        }

        $write->query($query, $vmcheckout);
        $checkout_id = $write->lastInsertId();

//        print_r($checkout_id);

        $quote = Mage::getSingleton('checkout/session')->getQuote();
        $grandTotal= $quote->getGrandTotal();
        $formattedgrandTotal = Mage::helper('core')->currency($grandTotal, true, false);
        //echo $formattedPrice;
        $cartItems = $quote->getAllVisibleItems();

//        echo "<pre>";
//        print_r($cartItems);
//        exit;
//        echo "</pre>";
        $cart_items = array();
        $cart_items_arr = array();
        foreach ($cartItems as $item) {
            $item_id= $item->getItemId();
            $item_name= $item->getName();
            $item_sku= $item->getSku();
            $item_qty= $item->getQty();
            $item_reason= $item->getReason();
            $item_price= $item->getPrice();

            $query2 = "insert into vm_cart_items "
                . "(item_id, item_name, item_sku, item_qty, item_reason, item_price, checkout_id) values "
                . "('$item_id', '$item_name', '$item_sku', '$item_qty', '$item_reason', '$item_price','$checkout_id')";

            $write->query($query2);

            $cart_items['item_id'] = $item_id;
            $cart_items['item_name'] = $item_name;
            $cart_items['item_sku'] = $item_sku;
            $cart_items['item_qty'] = $item_qty;
            $cart_items['item_reason'] = $item_reason;
            $cart_items['item_price'] = $item_price;
            array_push($cart_items_arr,$cart_items);
        }

        $vm_checkout_arr = [
            "lrs_location" => $vmcheckout['lrs_location'],
            "cost_center" => $vmcheckout['cost_center'],
            "customer_name" => $vmcheckout['customer_name'],
            "customer_id" => $vmcheckout['customer_id'],
            "customer_email" => $vmcheckout['customer_email'],
            "customer_mobile" => $vmcheckout['customer_mobile'],
            "hod_name" => $vmcheckout['hod_name'],
            "hod_email" => $vmcheckout['hod_email'],
            "afm_name" => $vmcheckout['afm_name'],
            "afm_email" => $vmcheckout['afm_email'],
            "grand_total" => $grandTotal,
            "formatted_grand_total" => $formattedgrandTotal,
            "checkout_id" =>$checkout_id,
            "cart_items" =>$cart_items_arr
        ];



        Mage::getSingleton('core/session')->setVmCheckout($vm_checkout_arr);
//        $myValue = Mage::getSingleton('core/session')->getVmCheckout();
//        echo '<pre>';
//        print_r($myValue);
//        echo '</pre>';

        $hod_id = $vmcheckout['hod_name'];

        $readConnection = Mage::getSingleton('core/resource')->getConnection('core_read');

        $sql = "Select `firstname` from `admin_user` WHERE `user_id`= $hod_id";
        $hod_names       = $readConnection->fetchAll($sql);
//        var_dump($hod_names);


  //      email sending start
//        $hod_email= $vmcheckout['hod_email'];
//
//        $emailTemplate = Mage::getModel('core/email_template')->loadDefault('recurring_order_email_template');
//
////Getting the Store E-Mail Sender Name.
//        $senderName = Mage::getStoreConfig('trans_email/ident_general/name');
//
////Getting the Store General E-Mail.
//        $senderEmail = Mage::getStoreConfig('trans_email/ident_general/email');
//
////Variables for Confirmation Mail.
//
//        $emailTemplateVariables = array();
//        $emailTemplateVariables['name'] = $vmcheckout['hod_name'];
//        $emailTemplateVariables['email'] = $vmcheckout['hod_email'];
//
////Appending the Custom Variables to Template.
//        $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
//
////Sending E-Mail to Customers.
//        $connection = Mage::getSingleton('core/resource')->getConnection('core_read');
//        $hod_id = $vmcheckout['hod_name'];
//        $hod_name = "Select `firstname` from `admin_user` WHERE user_id= `$hod_id`";
//
//
//        $msg = '<html><head><title>Commande de photos</title></head><body><p style="color: red; text-transform: uppercase;font-size: 16px;font-weight: bold;">Requested Cart Item Details</p><table>';
//        $msg .= '<table>';
//        $msg .= '<thead>';
//        $msg .= '<tr style="background: #ffff00;"> <td colspan="2" style="color: #323788;font-weight:bold;">Mills Virgin Website Order Details</td></tr></thead>';
//        $msg .= '<tbody>';
//        $msg .= '<tr><th>Order No</th><td>'.$checkout_id.'</td></tr>';
//        $msg .= '<tr><th>Tech Name</th><td>'.$vmcheckout['customer_name'].'</td></tr>';
//        $msg .= '<tr><th>Tech ID</th><td>'.$vmcheckout['customer_id'].'</td></tr>';
//        $msg .= '<tr><th>Tech Email</th><td>'.$vmcheckout['customer_email'].'</td></tr>';
//        $msg .= '<tr><th>Tech Mobile</th><td>'.$vmcheckout['customer_mobile'].'</td></tr>';
//        $msg .= '<tr><th>HOD Name</th><td>'.$hod_name.'</td></tr>';
//        $msg .= '<tr><th>HOD Email</th><td>'.$vmcheckout['hod_email'].'</td></tr>';
//        $msg .= '<tr><th>AFM Name</th><td>'.$vmcheckout['afm_name'].'</td></tr>';
//        $msg .= '<tr><th>AFM Email</th><td>'.$vmcheckout['afm_email'].'</td></tr>';
//        $msg .= '<tr><th>Order Date</th><td>'.$vmcheckout['customer_name'].'</td></tr>';
//        $msg .= '</tbody></table>';
//
//        $msg .= '<table><thead>';
//        $msg .= '<tr style="background: #ffff00;"> <td colspan="2" style="color: #323788;font-weight:bold;">LRS Location and Cost Centre</td></tr></thead>';
//        $msg .= '<tbody>';
//        $msg .= '<tr><th>LRS Location</th><td>'.$vmcheckout['lrs_location'].'</td></tr>';
//        $msg .= '<tr><th>Cost Centre</th><td>'.$vmcheckout['cost_center'].'</td></tr>';
//        $msg .= '</tbody></table>';
//
//        $msg .= '<table><thead><tr style="background: #ffff00;">';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Part No.</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Model</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Price</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Quantity</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Total</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Reason</td>';
//        $msg .= '</tr></thead><tbody>';
//        foreach($cartItems as $item){
//            $reason = "Select `reason` from `vm_reason` WHERE id= $item->getReason()";
//            $msg .= '<tr><td>' . $item->getSku() . '</td>';
//            $msg .= '<td>' . $item->getName() . '</td>';
//            $msg .= '<td>' . $item->getPrice() . '</td>';
//            $msg .= '<td>' . $item->getQty() . '</td>';
//            $msg .= '<td>' . $item->getPrice() . '</td>';
//            $msg .= '<td>' . $reason . '</td></tr>';
//        }
//        $msg .= '</tbody></table>';
//        $msg .= '</body></html>';
//
//        $mail = Mage::getModel('core/email')
//            ->setToName($senderName)
//            ->setToEmail($hod_email,$vmcheckout['afm_email'])
//            ->setBody($msg)
//            ->setSubject('Mills Virgin Web Order for Approval')
//            ->setFromEmail($senderEmail)
//            ->setFromName($senderName)
//            ->setType('html');
//        try{
//            //Confimation E-Mail Send
//            $mail->send();
//        }
//        catch(Exception $error)
//        {
//            Mage::getSingleton('core/session')->addError($error->getMessage());
//            return false;
//        }

        $this->loadLayout();
        $this->renderLayout();

        $parameters = $vm_checkout_arr;
        $this->_forward('hodEmail',NULL,NULL,$parameters);

    }

    public function hodEmailAction(){
        $lrs_id = $this->getRequest()->getParam('lrs_location');
        $cost_center_id = $this->getRequest()->getParam('cost_center');
        $checkout_id = $this->getRequest()->getParam('checkout_id');
        $customer_name= $this->getRequest()->getParam('customer_name');
        $customer_id = $this->getRequest()->getParam('customer_id');
        $customer_email = $this->getRequest()->getParam('customer_email');
        $customer_mobile = $this->getRequest()->getParam('customer_mobile');
        $hod_id = $this->getRequest()->getParam('hod_name');
        $hod_email = $this->getRequest()->getParam('hod_email');
        $afm_name = $this->getRequest()->getParam('afm_name');
        $afm_email = $this->getRequest()->getParam('afm_email');
        $grandTotal = $this->getRequest()->getParam('grand_total');
        $formattedgrandTotal = $this->getRequest()->getParam('formatted_grand_total');
        $cartItems = $this->getRequest()->getParam('cart_items');

//        echo '<pre>';
//        print_r($lrs_location);
//        echo '</pre>';

        //      email sending start
//        $emailTemplate = Mage::getModel('core/email_template')->loadDefault('custom_email_template1');
//
////Getting the Store E-Mail Sender Name.
//        $senderName = Mage::getStoreConfig('trans_email/ident_general/name');
//
////Getting the Store General E-Mail.
//        $senderEmail = Mage::getStoreConfig('trans_email/ident_general/email');
//
////Sending E-Mail to Customers.
//
//
//        $readConnection = Mage::getSingleton('core/resource')->getConnection('core_read');
//
//        $sql = "Select * from `admin_user` WHERE `user_id`= $hod_id";
//        $hod_names       = $readConnection->fetchAll($sql);
//
//        $sql2 = "Select `site` from `vm_lrslocations` WHERE `id`= $lrs_id";
//        $lrs_site       = $readConnection->fetchAll($sql2);
//
//        $sql3 = "Select * from `vm_costcenters` WHERE `id`= $cost_center_id";
//        $cost_center       = $readConnection->fetchAll($sql3);
//
//        $sql4 = "Select `order_date` from `vm_checkout` WHERE `id`= $checkout_id";
//        $order_date_time       = $readConnection->fetchAll($sql4);
//        $order_timestamp = strtotime($order_date_time[0]['order_date']);
//        $order_date = date('F j, Y', $order_timestamp);
//
//
//
//        $msg = '<html><head><title>Commande de photos</title></head><body><p style="color: red; text-transform: uppercase;font-size: 16px;font-weight: bold;">SENT TO HOD FOR APPROVAL</p><table>';
//        $msg .= '<table width="100%" border="0">';
//        $msg .= '<thead>';
//        $msg .= '<tr style="background: #ffff00;"> <td colspan="2" style="color: #323788;font-weight:bold;">Mills Virgin Website Order Details</td></tr></thead>';
//        $msg .= '<tbody>';
//        $msg .= '<tr><td width="25%">Order No</td><td>'.$checkout_id.'</td></tr>';
//        $msg .= '<tr><td>Tech Name</td><td>'.$customer_name.'</td></tr>';
//        $msg .= '<tr><td>Tech ID</td><td>'.$customer_id.'</td></tr>';
//        $msg .= '<tr><td>Tech Email</td><td>'.$customer_email.'</td></tr>';
//        $msg .= '<tr><td>Tech Mobile</td><td>'.$customer_mobile.'</td></tr>';
//        $msg .= '<tr><td>HOD Name</td><td>'.$hod_names[0]['firstname']." ".$hod_names[0]['lastname'].'</td></tr>';
//        $msg .= '<tr><td>HOD Email</td><td>'.$hod_email.'</td></tr>';
//        $msg .= '<tr><td>AFM Name</td><td>'.$afm_name.'</td></tr>';
//        $msg .= '<tr><td>AFM Email</td><td>'.$afm_email.'</td></tr>';
//        $msg .= '<tr><td>Order Date</td><td>'.$order_date.'</td></tr>';
//        $msg .= '</tbody></table>';
//
//        $msg .= '<table width="100%" border="0"><thead>';
//        $msg .= '<tr style="background: #ffff00;"> <td colspan="2" style="color: #323788;font-weight:bold;">LRS Location and Cost Centre</td></tr></thead>';
//        $msg .= '<tbody>';
//        $msg .= '<tr><td width="25%">LRS Location</td><td>'.$lrs_site[0]['site'].'</td></tr>';
//        $msg .= '<tr><td>Cost Centre</td><td>'.$cost_center[0]['cost_center']."-".$cost_center[0]['business_area']."-".$cost_center[0]['region']."-".$cost_center[0]['area'].'</td></tr>';
//        $msg .= '</tbody></table>';
//
//        $msg .= '<table width="100%" border="0"><thead><tr style="background: #ffff00;">';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Part No.</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Model</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Price</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Quantity</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Total</td>';
//        $msg .= '<td style="color: #323788;font-weight:bold;">Reason</td>';
//        $msg .= '</tr></thead><tbody>';
//
//        for ($i=0; $i<count($cartItems); $i++){
//            $reason_id = $cartItems[$i]['item_reason'];
//            $reason_sql = "Select `reason` from `vm_reason` WHERE `id`= $reason_id";
//            $reason  = $readConnection->fetchAll($reason_sql);
//            $msg .= '<tr><td>' . $cartItems[$i]['item_sku'] . '</td>';
//            $msg .= '<td>' .$cartItems[$i]['item_name'] . '</td>';
//            $msg .= '<td>' .$cartItems[$i]['item_price'] . '</td>';
//            $msg .= '<td>' .$cartItems[$i]['item_qty'] . '</td>';
//            $msg .= '<td>' .$cartItems[$i]['item_price'] . '</td>';
//            $msg .= '<td>' . $reason[0]['reason'] . '</td></tr>';
//        }
//        $msg .= '</tbody></table>';
//
//        $vatPrice = (0.2 * $grandTotal);
//        $formattedvatPrice = Mage::helper('core')->currency($vatPrice, true, false);
//        $endPrice = $vatPrice + $grandTotal;
//        $formattedendPrice= Mage::helper('core')->currency($endPrice, true, false);
//        $formattedshipping= Mage::helper('core')->currency(0.00, true, false);
//
//        $msg .= '<table width="100%" border="0">';
//        $msg .= '<tr style="color:#323788"><td>Total Price (Before VAT)</td><td style="text-align:right">'.$formattedgrandTotal.'</td></tr>';
//        $msg .= '<tr style="color:#323788"><td>Shipping</td><td style="text-align:right">'.$formattedshipping.'</td></tr>';
//        $msg .= '<tr style="color:#323788"><td>Final Price (Before VAT)</td><td style="text-align:right">'.$formattedgrandTotal.'</td></tr>';
//        $msg .= '<tr style="color:#323788"><td>VAT at 20%</td><td style="text-align:right">'.$formattedvatPrice.'</td></tr>';
//        $msg .= '<tr bgcolor="#ffff00"><td>Final Price (After VAT 20%)</td><td style="text-align:right">'.$formattedendPrice.'</td></tr>';
//        $msg .= '<table>';
//        $msg .= '</body></html>';
//
//        $mail = Mage::getModel('core/email')
//            ->setToName($senderName)
//            ->setToEmail($hod_email)
//            ->setBody($msg)
//            ->setSubject('Mills Virgin Web Order for Approval')
//            ->setFromEmail($senderEmail)
//            ->setFromName($senderName)
//            ->setType('html');
//        try{
//            //Confimation E-Mail Send
//            $mail->send();
//        }
//        catch(Exception $error)
//        {
//            Mage::getSingleton('core/session')->addError($error->getMessage());
//            return false;
//        }
    }

    public function confirmAction(){

        $checkout_id = $this->getRequest()->getParam('id');
//        $checkout_arr = json_decode( base64_decode( $checkout_id ) );

        $dirty = array("+", "/", "=");
        $clean = array("_PLS_", "_SLS_", "_EQLS_");

        $key= "onec";
        $decrypted_string = str_replace($clean, $dirty, $checkout_id);
        $checkout_json= rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($decrypted_string), MCRYPT_MODE_CBC, md5($key)), "\0");


        $checkout_arr = json_decode( $checkout_json);
        print_r($checkout_arr);

        exit;

        $write = Mage::getSingleton('core/resource')->getConnection('core_write');
        $query = "UPDATE `vm_checkout` SET status = '1' where id = $checkout_id";
        $write->query($query);

        Mage::register('checkout_id',$checkout_id);
        $this->loadLayout();
        $this->renderLayout();

    }

}