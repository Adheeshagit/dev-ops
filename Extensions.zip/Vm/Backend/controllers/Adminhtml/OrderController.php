<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/11/16
 * Time: 5:17 PM
 * To change this template use File | Settings | File Templates.
 */

class Vm_Backend_Adminhtml_OrderController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
//        $order=Mage::getModel('checkout/order');
//        $order->setCustomerName('test customer')->save();
//        Mage::getSingleton('adminhtml/session')->addSuccess(
//            'Event saved. ID = '.$order->getId()
//        );
//        $this->loadLayout();
//        return $this->renderLayout();

        //echo'hi';exit;
        $this->loadLayout();
        $this->_setActiveMenu('backend/orders');
        $this->_addContent($this->getLayout()->createBlock('backend/adminhtml_order'));
        return $this->renderLayout();
    }

    public function exportVirginCsvAction()
    {
        $fileName = 'orders_virgin.csv';
        $grid = $this->getLayout()->createBlock('backend/adminhtml_order_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }
}