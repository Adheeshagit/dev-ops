<?php
/**
 * Created by JetBrains PhpStorm.
 * User: User
 * Date: 7/11/16
 * Time: 5:25 PM
 * To change this template use File | Settings | File Templates.
 */

class Vm_Backend_Block_Adminhtml_Order extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_blockGroup = 'backend';
        $this->_controller = 'adminhtml_order';
        $this->_headerText = Mage::helper('backend')->__('Orders');
        $this->_addButtonLabel = Mage::helper('backend')->__('Add new Order');
        parent::__construct();
        //$this->_removeButton('add');
    }
}